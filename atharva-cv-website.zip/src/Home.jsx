
import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Mail, Phone, Linkedin, Github, Download } from "lucide-react";

export default function Home() {
  return (
    <main className="min-h-screen bg-white text-gray-900 dark:bg-gray-950 dark:text-white p-6">
      <div className="max-w-4xl mx-auto">
        <header className="mb-8">
          <h1 className="text-4xl font-bold">Atharva Patwardhan</h1>
          <p className="text-lg mt-2">
            Engineering Student | AI/ML | Augmented Reality | Hackathon Winner
          </p>
          <div className="flex items-center gap-4 mt-4 text-sm">
            <a href="mailto:atharva.patwardhan21@gmail.com" className="flex items-center gap-1"><Mail size={16} /> atharva.patwardhan21@gmail.com</a>
            <span className="flex items-center gap-1"><Phone size={16} /> 8830083910</span>
            <a href="https://www.linkedin.com/in/atharva-patwardhan-8b204b30a" target="_blank" className="flex items-center gap-1"><Linkedin size={16} /> LinkedIn</a>
            <a href="https://github.com/" target="_blank" className="flex items-center gap-1"><Github size={16} /> GitHub</a>
          </div>
        </header>

        <section className="mb-8">
          <h2 className="text-2xl font-semibold mb-2">About Me</h2>
          <p>
            Dynamic engineering student at VIT Pune, specializing in AI/ML and Augmented Reality. Strong problem-solving and teamwork skills, demonstrated through award-winning projects like AR Wardrobe, HeamoScan, and more. Proficient in building full-stack applications and AI solutions, with a passion for innovation and hackathons.
          </p>
        </section>

        <section className="mb-8">
          <h2 className="text-2xl font-semibold mb-2">Skills</h2>
          <ul className="grid grid-cols-2 gap-2 list-disc list-inside">
            <li>Machine Learning & Deep Learning</li>
            <li>Augmented Reality (Unity, Blender, ARCore)</li>
            <li>Computer Vision (OpenCV, DeepLabV3)</li>
            <li>Web Development (React.js, Node.js, MongoDB)</li>
            <li>Data Analysis, UI/UX Design</li>
            <li>Python, ESP32, IoT Systems</li>
          </ul>
        </section>

        <section className="mb-8">
          <h2 className="text-2xl font-semibold mb-2">Projects</h2>
          <ul className="space-y-2 list-disc list-inside">
            <li><strong>HeamoScan</strong>: Deep learning-based hemoglobin prediction from nail images.</li>
            <li><strong>Loan Default Prediction</strong>: ML model to assess loan default risk, 1st in hackathon.</li>
            <li><strong>Crop Yield Prediction</strong>: Regression model based on soil/weather, 2nd in innovation challenge.</li>
            <li><strong>AR Wardrobe</strong>: AR-based virtual try-on with personalized recommendations.</li>
            <li><strong>Women Safety Device</strong>: IoT emergency alert system using GPS and ESP32.</li>
            <li><strong>CBM System</strong>: Audio-based fault detection for tunnel booster fans.</li>
          </ul>
        </section>

        <section className="mb-8">
          <h2 className="text-2xl font-semibold mb-2">Education</h2>
          <ul className="list-disc list-inside">
            <li>B.Tech in AI & ML, Vishwakarma Institute of Technology, Pune (2023 – 2027)</li>
            <li>Ferguson Junior College, Pune (High School – 2023)</li>
          </ul>
        </section>

        <section className="mb-8">
          <h2 className="text-2xl font-semibold mb-2">Experience</h2>
          <p>
            <strong>Project Intern – Trueview (2024–2025)</strong><br />
            Led development of AR Wardrobe using ARCore, Unity, and React.js. Built ML recommendation engine and integrated full-stack architecture.
          </p>
        </section>

        <section className="mb-8">
          <h2 className="text-2xl font-semibold mb-2">Accomplishments</h2>
          <ul className="list-disc list-inside">
            <li>Smart India Hackathon Internal Round Winner</li>
            <li>Techathon 2.0 Best Solution Winner</li>
            <li>IUCAA Project Competition Winner</li>
            <li>Smart School Hackathon Winner</li>
          </ul>
        </section>

        <section className="mb-8">
          <Button asChild className="flex gap-2">
            <a href="/Atharva_Patwardhan_Resume.pdf" download>
              <Download size={18} /> Download Resume
            </a>
          </Button>
        </section>

        <section className="mb-12">
          <h2 className="text-2xl font-semibold mb-2">Contact Me</h2>
          <form className="space-y-4">
            <input type="text" placeholder="Your Name" className="w-full p-2 rounded border" required />
            <input type="email" placeholder="Your Email" className="w-full p-2 rounded border" required />
            <textarea placeholder="Your Message" className="w-full p-2 rounded border" rows="4" required></textarea>
            <Button type="submit">Send Message</Button>
          </form>
        </section>
      </div>
    </main>
  );
}
